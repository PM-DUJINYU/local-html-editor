(function attachZip(global) {
  const ns = (global.LocalHtmlEditor = global.LocalHtmlEditor || {});
  const encoder = new TextEncoder();
  const crcTable = makeCrcTable();

  function makeCrcTable() {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[n] = c >>> 0;
    }
    return table;
  }

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i += 1) {
      crc = crcTable[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function toBytes(data) {
    if (data instanceof Uint8Array) return data;
    if (typeof data === "string") return encoder.encode(data);
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    throw new Error("Unsupported ZIP entry data");
  }

  function dosDateTime(date) {
    const d = date || new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
    const day = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time, day };
  }

  function writeU16(out, value) {
    out.push(value & 0xff, (value >>> 8) & 0xff);
  }

  function writeU32(out, value) {
    out.push(value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff);
  }

  function pushBytes(out, bytes) {
    for (let i = 0; i < bytes.length; i += 1) out.push(bytes[i]);
  }

  function createZipBytes(entries) {
    const local = [];
    const central = [];
    const records = [];
    let offset = 0;
    const stamp = dosDateTime(new Date());

    for (const entry of entries) {
      const nameBytes = encoder.encode(entry.name);
      const data = toBytes(entry.data);
      const crc = crc32(data);
      const startOffset = offset;

      writeU32(local, 0x04034b50);
      writeU16(local, 20);
      writeU16(local, 0x0800);
      writeU16(local, 0);
      writeU16(local, stamp.time);
      writeU16(local, stamp.day);
      writeU32(local, crc);
      writeU32(local, data.length);
      writeU32(local, data.length);
      writeU16(local, nameBytes.length);
      writeU16(local, 0);
      pushBytes(local, nameBytes);
      pushBytes(local, data);
      offset += 30 + nameBytes.length + data.length;

      records.push({ nameBytes, data, crc, startOffset });
    }

    const centralStart = offset;
    for (const record of records) {
      writeU32(central, 0x02014b50);
      writeU16(central, 20);
      writeU16(central, 20);
      writeU16(central, 0x0800);
      writeU16(central, 0);
      writeU16(central, stamp.time);
      writeU16(central, stamp.day);
      writeU32(central, record.crc);
      writeU32(central, record.data.length);
      writeU32(central, record.data.length);
      writeU16(central, record.nameBytes.length);
      writeU16(central, 0);
      writeU16(central, 0);
      writeU16(central, 0);
      writeU16(central, 0);
      writeU32(central, 0);
      writeU32(central, record.startOffset);
      pushBytes(central, record.nameBytes);
    }

    const centralSize = central.length;
    const end = [];
    writeU32(end, 0x06054b50);
    writeU16(end, 0);
    writeU16(end, 0);
    writeU16(end, records.length);
    writeU16(end, records.length);
    writeU32(end, centralSize);
    writeU32(end, centralStart);
    writeU16(end, 0);

    return new Uint8Array([...local, ...central, ...end]);
  }

  function createZipBlob(entries) {
    return new Blob([createZipBytes(entries)], { type: "application/zip" });
  }

  ns.Zip = {
    crc32,
    createZipBytes,
    createZipBlob
  };
})(globalThis);
