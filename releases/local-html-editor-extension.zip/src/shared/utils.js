(function attachUtils(global) {
  const ns = (global.LocalHtmlEditor = global.LocalHtmlEditor || {});

  function isLocalHtmlPage(locationLike, doc) {
    const href = locationLike && locationLike.href ? locationLike.href : "";
    if (!href.startsWith("file://")) return false;
    const path = decodeURIComponent((locationLike.pathname || "").toLowerCase());
    return path.endsWith(".html") || path.endsWith(".htm") || doc.contentType === "text/html";
  }

  function stableHash(input) {
    let hash = 2166136261;
    const text = String(input || "");
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function debounce(fn, wait) {
    let timer = null;
    return function debounced(...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function formatClock(timestamp) {
    return new Date(timestamp).toLocaleTimeString("zh-CN", { hour12: false });
  }

  function dateKey(timestamp) {
    const date = new Date(timestamp);
    return [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, "0"),
      String(date.getDate()).padStart(2, "0")
    ].join("-");
  }

  function safeFileName(value, fallback) {
    const base = String(value || fallback || "index")
      .trim()
      .replace(/[\\/:*?"<>|#%&{}$!'@+=`~]/g, "-")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "");
    return base || fallback || "index";
  }

  function uniqueId(prefix) {
    if (global.crypto && global.crypto.randomUUID) {
      return `${prefix}-${global.crypto.randomUUID()}`;
    }
    return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  }

  function readFileAsDataURL(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error || new Error("读取文件失败"));
      reader.readAsDataURL(file);
    });
  }

  function dataURLToBytes(dataURL) {
    const match = String(dataURL).match(/^data:([^;,]+)?(;base64)?,(.*)$/);
    if (!match) throw new Error("Invalid data URL");
    const isBase64 = Boolean(match[2]);
    const body = match[3] || "";
    const binary = isBase64 ? atob(body) : decodeURIComponent(body);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function bytesToDataURL(bytes, mime) {
    let binary = "";
    for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
    return `data:${mime || "application/octet-stream"};base64,${btoa(binary)}`;
  }

  function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error || new Error("读取 Blob 失败"));
      reader.readAsDataURL(blob);
    });
  }

  function extensionFromMime(mime) {
    const map = {
      "image/jpeg": "jpg",
      "image/png": "png",
      "image/gif": "gif",
      "image/webp": "webp",
      "image/svg+xml": "svg"
    };
    return map[mime] || "bin";
  }

  function sizeLabel(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  ns.Utils = {
    isLocalHtmlPage,
    stableHash,
    debounce,
    formatClock,
    dateKey,
    safeFileName,
    uniqueId,
    readFileAsDataURL,
    dataURLToBytes,
    bytesToDataURL,
    blobToDataURL,
    extensionFromMime,
    sizeLabel
  };
})(globalThis);
