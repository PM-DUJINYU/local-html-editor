(function attachExporter(global) {
  const ns = (global.LocalHtmlEditor = global.LocalHtmlEditor || {});

  function prepareExport(doc, mode) {
    const clone = doc.documentElement.cloneNode(true);
    const assets = [];
    const usedNames = new Set();

    removePluginNodes(clone);
    processImages(clone, mode, assets, usedNames);
    cleanPluginAttributes(clone);

    return {
      html: `<!DOCTYPE html>\n${clone.outerHTML}`,
      assets
    };
  }

  function removePluginNodes(root) {
    root.querySelectorAll("[data-lhe-ui]").forEach((node) => node.remove());
  }

  function processImages(root, mode, assets, usedNames) {
    root.querySelectorAll("img[data-lhe-new-image='true']").forEach((img, index) => {
      const src = img.getAttribute("src") || "";
      if (mode !== "zip" || !src.startsWith("data:")) return;

      const mime = (src.match(/^data:([^;,]+)/) || [])[1] || "application/octet-stream";
      const ext = ns.Utils.extensionFromMime(mime);
      const rawName = img.getAttribute("data-lhe-file-name") || `image-${index + 1}.${ext}`;
      const baseName = ns.Utils.safeFileName(rawName.replace(/\.[^.]+$/, ""), `image-${index + 1}`);
      let name = `assets/${baseName}.${ext}`;
      let n = 2;
      while (usedNames.has(name)) {
        name = `assets/${baseName}-${n}.${ext}`;
        n += 1;
      }
      usedNames.add(name);
      assets.push({ name, data: ns.Utils.dataURLToBytes(src) });
      img.setAttribute("src", name);
    });
  }

  function cleanPluginAttributes(root) {
    const nodes = [root, ...root.querySelectorAll("*")];
    nodes.forEach((node) => {
      if (!node.attributes) return;
      [...node.attributes].forEach((attr) => {
        if (
          attr.name === "contenteditable" ||
          attr.name === "spellcheck" ||
          attr.name.startsWith("data-lhe")
        ) {
          node.removeAttribute(attr.name);
        }
      });
      if (node.classList) {
        [...node.classList].forEach((className) => {
          if (className.startsWith("lhe-")) node.classList.remove(className);
        });
        if (!node.getAttribute("class")) node.removeAttribute("class");
      }
    });
  }

  ns.Exporter = {
    prepareExport
  };
})(globalThis);
