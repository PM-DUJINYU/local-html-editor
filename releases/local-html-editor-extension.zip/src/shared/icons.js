(function attachIcons(global) {
  const ns = (global.LocalHtmlEditor = global.LocalHtmlEditor || {});
  const attrs = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
  const paths = {
    edit: '<path d="M4 20h4l11-11a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    eye: '<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="3"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 1 1 0 12h-2"/>',
    redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 1 0 0 12h2"/>',
    bold: '<path d="M8 5h6a3 3 0 0 1 0 6H8z"/><path d="M8 11h7a3.5 3.5 0 0 1 0 7H8z"/>',
    italic: '<path d="M10 5h8"/><path d="M6 19h8"/><path d="m14 5-4 14"/>',
    underline: '<path d="M7 5v6a5 5 0 0 0 10 0V5"/><path d="M5 21h14"/>',
    strike: '<path d="M6 16a6 6 0 0 0 11.5-1.5c0-3-3-3.5-5.5-4S7 9 7 6.5A4 4 0 0 1 15 5"/><path d="M4 12h16"/>',
    list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
    ordered: '<path d="M10 6h11"/><path d="M10 12h11"/><path d="M10 18h11"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M3.5 14h2.5L4 18h2.5"/>',
    indent: '<path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/><path d="m4 8 4 4-4 4"/>',
    outdent: '<path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/><path d="m8 8-4 4 4 4"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.1 0l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.1 0l-2 2a5 5 0 0 0 7.1 7.1l1.1-1.1"/>',
    image: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="m21 15-5-5L5 19"/>',
    width: '<path d="M4 12h16"/><path d="m8 8-4 4 4 4"/><path d="m16 8 4 4-4 4"/>',
    brush: '<path d="m18 3 3 3-9 9H9v-3z"/><path d="M8 14s-4 1-4 5c2 1 5 0 5-4Z"/>',
    eraser: '<path d="m7 21-4-4 10-10a3 3 0 0 1 4 0l2 2a3 3 0 0 1 0 4l-8 8Z"/><path d="M11 21h10"/><path d="m8 12 5 5"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l3 3v13a2 2 0 0 1-2 2Z"/><path d="M7 3v5h9"/><path d="M7 21v-8h10v8"/>',
    archive: '<path d="M4 7h16"/><path d="M5 7v14h14V7"/><path d="M3 3h18v4H3z"/><path d="M10 12h4"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/>',
    close: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v6h-6"/>',
    palette: '<path d="M12 3a9 9 0 0 0 0 18h1.5a2 2 0 0 0 1-3.7 1.5 1.5 0 0 1 .5-2.9h1A5 5 0 0 0 16 4.5 9 9 0 0 0 12 3Z"/><circle cx="7.5" cy="10" r=".7"/><circle cx="10" cy="7.5" r=".7"/><circle cx="13" cy="7.5" r=".7"/>',
    text: '<path d="M4 7V4h16v3"/><path d="M12 4v16"/><path d="M8 20h8"/>',
    align: '<path d="M4 6h16"/><path d="M4 12h10"/><path d="M4 18h16"/>',
    vertical: '<path d="M12 3v18"/><path d="m8 7 4-4 4 4"/><path d="m8 17 4 4 4-4"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>'
  };

  function svg(name) {
    return `<svg ${attrs}>${paths[name] || paths.text}</svg>`;
  }

  ns.Icons = { svg };
})(globalThis);
