(function attachStore(global) {
  const ns = (global.LocalHtmlEditor = global.LocalHtmlEditor || {});
  const DB_NAME = "local-html-editor";
  const DB_VERSION = 1;
  const SNAPSHOT_LIMIT = 10;

  function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("drafts")) {
          db.createObjectStore("drafts", { keyPath: "fingerprint" });
        }
        if (!db.objectStoreNames.contains("snapshots")) {
          const snapshots = db.createObjectStore("snapshots", { keyPath: "id" });
          snapshots.createIndex("fingerprint", "fingerprint", { unique: false });
          snapshots.createIndex("createdAt", "createdAt", { unique: false });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("IndexedDB 打开失败"));
    });
  }

  async function tx(storeName, mode, callback) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, mode);
      const store = transaction.objectStore(storeName);
      let result;
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () => reject(transaction.error || new Error("IndexedDB 写入失败"));
      result = callback(store);
    });
  }

  function requestToPromise(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("IndexedDB 请求失败"));
    });
  }

  async function saveDraft(draft) {
    return putWithCleanup("drafts", draft.fingerprint, draft);
  }

  async function getDraft(fingerprint) {
    return tx("drafts", "readonly", (store) => requestToPromise(store.get(fingerprint)));
  }

  async function addSnapshot(snapshot) {
    await putWithCleanup("snapshots", snapshot.id, snapshot);
    await enforceSnapshotLimit(snapshot.fingerprint);
    return snapshot;
  }

  async function getSnapshot(id) {
    return tx("snapshots", "readonly", (store) => requestToPromise(store.get(id)));
  }

  async function listSnapshots(fingerprint) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction("snapshots", "readonly");
      const store = transaction.objectStore("snapshots");
      const request = fingerprint
        ? store.index("fingerprint").getAll(fingerprint)
        : store.getAll();
      request.onsuccess = () => {
        const rows = (request.result || []).sort((a, b) => b.createdAt - a.createdAt);
        resolve(rows);
      };
      request.onerror = () => reject(request.error || new Error("读取历史失败"));
    });
  }

  async function deleteSnapshot(id) {
    return tx("snapshots", "readwrite", (store) => store.delete(id));
  }

  async function enforceSnapshotLimit(fingerprint) {
    const rows = await listSnapshots(fingerprint);
    const overflow = rows.slice(SNAPSHOT_LIMIT);
    for (const row of overflow) {
      await deleteSnapshot(row.id);
    }
  }

  async function cleanupOldestSnapshot(fingerprint) {
    const rows = await listSnapshots(fingerprint);
    const allRows = rows.length ? rows : await listSnapshots();
    const target = allRows[allRows.length - 1];
    if (!target) return false;
    await deleteSnapshot(target.id);
    return true;
  }

  async function putWithCleanup(storeName, key, value) {
    try {
      return await tx(storeName, "readwrite", (store) => store.put(value));
    } catch (error) {
      const cleaned = await cleanupOldestSnapshot(value.fingerprint);
      if (!cleaned) throw error;
      return tx(storeName, "readwrite", (store) => store.put(value));
    }
  }

  ns.Store = {
    SNAPSHOT_LIMIT,
    saveDraft,
    getDraft,
    addSnapshot,
    getSnapshot,
    listSnapshots,
    deleteSnapshot,
    enforceSnapshotLimit,
    cleanupOldestSnapshot
  };
})(globalThis);
