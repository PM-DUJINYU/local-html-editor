(function initLocalHtmlEditor() {
  const ns = window.LocalHtmlEditor;
  if (!ns || window.__LHE_LOADED__) return;
  if (!ns.Utils.isLocalHtmlPage(window.location, document)) return;
  window.__LHE_LOADED__ = true;

  const initialHtml = document.documentElement.outerHTML;
  const fingerprint = `${window.location.href}::${ns.Utils.stableHash(initialHtml)}`;
  const state = {
    fingerprint,
    editing: false,
    selectedElement: null,
    savedRange: null,
    toolbar: null,
    floatingButton: null,
    historyDrawer: null,
    statusNode: null,
    imageInput: null,
    formatBrush: null,
    formatMenu: null,
    colorMenu: null,
    fontSizeMenu: null,
    lastSnapshotDate: ns.Utils.dateKey(Date.now()),
    currentDraft: null
  };

  const autosave = ns.Utils.debounce(() => saveDraft(), 700);
  const t = ns.I18n.t;
  const colorPresets = [
    ["#0f172a", "#334155", "#64748b", "#94a3b8", "#e2e8f0"],
    ["#7f1d1d", "#b91c1c", "#ef4444", "#fca5a5", "#fee2e2"],
    ["#7c2d12", "#c2410c", "#f97316", "#fdba74", "#ffedd5"],
    ["#713f12", "#ca8a04", "#eab308", "#fde047", "#fef9c3"],
    ["#14532d", "#15803d", "#22c55e", "#86efac", "#dcfce7"],
    ["#134e4a", "#0f766e", "#14b8a6", "#5eead4", "#ccfbf1"],
    ["#1e3a8a", "#2563eb", "#3b82f6", "#93c5fd", "#dbeafe"],
    ["#581c87", "#7e22ce", "#a855f7", "#d8b4fe", "#f3e8ff"],
    ["#831843", "#be185d", "#ec4899", "#f9a8d4", "#fce7f3"],
    ["#44403c", "#78716c", "#a8a29e", "#d6d3d1", "#f5f5f4"]
  ];

  boot();

  async function boot() {
    injectFloatingButton();
    bindDocumentEvents();
    const draft = await ns.Store.getDraft(state.fingerprint).catch(() => null);
    if (draft && draft.html && draft.updatedAt) showDraftBanner(draft);
  }

  function bindDocumentEvents() {
    document.addEventListener("selectionchange", saveSelection);
    document.addEventListener("input", noteChange, true);
    document.addEventListener("click", handleDocumentClick, true);
    document.addEventListener("mouseover", handleHover, true);
    document.addEventListener("mouseout", clearHover, true);
    document.addEventListener("paste", handlePaste, true);
    document.addEventListener("keydown", handleShortcuts, true);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") createSnapshot("page-hidden", "auto");
    });
    window.addEventListener("pagehide", () => createSnapshot("page-closed", "auto"));

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message) return false;
      if (message.type === "lhe-get-page-info") {
        sendResponse({
          ok: true,
          fingerprint: state.fingerprint,
          title: document.title || "未命名 HTML",
          url: window.location.href,
          editing: state.editing
        });
        return false;
      }
      if (message.type === "lhe-restore-snapshot") {
        restoreSnapshot(message.snapshot).then(sendResponse);
        return true;
      }
      return false;
    });
  }

  function injectFloatingButton() {
    if (state.floatingButton && document.contains(state.floatingButton)) return;
    const button = document.createElement("button");
    button.id = "lhe-floating-button";
    button.type = "button";
    button.setAttribute("data-lhe-ui", "true");
    button.setAttribute("contenteditable", "false");
    button.setAttribute("aria-label", t("enterEditMode"));
    button.title = t("enterEditMode");
    button.innerHTML = ns.Icons.svg("edit");
    button.addEventListener("click", () => toggleEditing());
    document.body.appendChild(button);
    state.floatingButton = button;
  }

  function toggleEditing(force) {
    const next = typeof force === "boolean" ? force : !state.editing;
    if (next === state.editing) return;
    next ? enterEditMode() : leaveEditMode();
  }

  function enterEditMode() {
    state.editing = true;
    document.body.classList.add("lhe-editing");
    document.body.setAttribute("contenteditable", "true");
    document.body.setAttribute("spellcheck", "false");
    document.body.setAttribute("data-lhe-root-editable", "true");
    if (state.floatingButton) {
      state.floatingButton.innerHTML = ns.Icons.svg("eye");
      state.floatingButton.title = t("exitEditMode");
      state.floatingButton.setAttribute("aria-label", t("exitEditMode"));
    }
    document.execCommand("styleWithCSS", false, true);
    injectToolbar();
    setStatus(`${t("autosaved")} --:--:--`);
  }

  function leaveEditMode() {
    state.editing = false;
    document.body.classList.remove("lhe-editing");
    document.body.removeAttribute("contenteditable");
    document.body.removeAttribute("spellcheck");
    document.body.removeAttribute("data-lhe-root-editable");
    clearSelectionMarker();
    clearHover();
    if (state.toolbar) state.toolbar.remove();
    state.toolbar = null;
    if (state.historyDrawer) state.historyDrawer.remove();
    state.historyDrawer = null;
    closeFormatMenu();
    closeColorMenu();
    closeFontSizeMenu();
    if (state.floatingButton) {
      state.floatingButton.innerHTML = ns.Icons.svg("edit");
      state.floatingButton.title = t("enterEditMode");
      state.floatingButton.setAttribute("aria-label", t("enterEditMode"));
    }
  }

  function injectToolbar() {
    if (state.toolbar && document.contains(state.toolbar)) return;
    const toolbar = document.createElement("div");
    toolbar.id = "lhe-toolbar";
    toolbar.setAttribute("data-lhe-ui", "true");
    toolbar.setAttribute("contenteditable", "false");
    toolbar.innerHTML = `
      <div class="lhe-brand"><span>Designed by</span><strong>JinyuDu</strong></div>
      <div class="lhe-group">
        ${toolButton("undo", "undo", t("undo"))}
        ${toolButton("redo", "redo", t("redo"))}
      </div>
      <div class="lhe-group">
        ${toolButton("bold", "bold", t("bold"))}
        ${toolButton("italic", "italic", t("italic"))}
        ${toolButton("underline", "underline", t("underline"))}
        ${toolButton("strikeThrough", "strike", t("strike"))}
      </div>
      <div class="lhe-group lhe-size-group">
        ${fontSizeSelect()}
        ${toolbarSelect("lineHeight", t("lineHeight"), [["1.0", "1.0"], ["1.2", "1.2"], ["1.4", "1.4"], ["1.5", "1.5"], ["1.75", "1.75"], ["2", "2"], ["2.5", "2.5"], ["3", "3"]], "line-height")}
      </div>
      <div class="lhe-group">
        ${colorButton("foreColor", t("textColor"), "#111111")}
        ${colorButton("hiliteColor", t("highlight"), "#fef08a")}
      </div>
      <div class="lhe-group">
        ${toolbarSelect("align", t("align"), [[t("alignLeft"), "left"], [t("alignCenter"), "center"], [t("alignRight"), "right"], [t("alignJustify"), "full"]], "align", "left")}
        ${toolbarSelect("verticalAlign", t("verticalAlign"), [[t("verticalTop"), "top"], [t("verticalMiddle"), "middle"], [t("verticalBottom"), "bottom"]], "vertical", "top")}
      </div>
      <div class="lhe-group">
        ${toolButton("insertUnorderedList", "list", t("bulletList"))}
        ${toolButton("insertOrderedList", "ordered", t("orderedList"))}
        ${toolButton("outdent", "outdent", t("outdent"))}
        ${toolButton("indent", "indent", t("indent"))}
      </div>
      <div class="lhe-group">
        ${actionButton("link", "link", t("link"))}
        ${actionButton("image", "image", t("image"))}
        ${actionButton("imageWidth", "width", t("imageWidth"))}
        ${actionButton("formatBrush", "brush", t("formatBrush"))}
        ${toolButton("removeFormat", "eraser", t("clearFormat"))}
      </div>
      <span class="lhe-spacer"></span>
      <span id="lhe-save-status" class="lhe-status">${t("autosaved")} --:--:--</span>
      <div class="lhe-group">
        ${actionButton("saveHtml", "save", t("saveHtml"))}
        ${actionButton("saveZip", "archive", t("saveZip"))}
        ${actionButton("history", "history", t("history"))}
      </div>
      <input id="lhe-image-input" type="file" accept="image/*" hidden>
    `;
    toolbar.addEventListener("mousedown", (event) => {
      if (event.target.closest("[data-style='fontSize']")) saveSelection();
      if (event.target.closest("button")) event.preventDefault();
    });
    toolbar.addEventListener("click", handleToolbarClick);
    toolbar.addEventListener("change", handleToolbarChange);
    toolbar.addEventListener("keydown", handleToolbarKeydown);
    document.body.appendChild(toolbar);
    state.toolbar = toolbar;
    state.statusNode = toolbar.querySelector("#lhe-save-status");
    state.imageInput = toolbar.querySelector("#lhe-image-input");
    state.imageInput.addEventListener("change", handleImagePicked);
  }

  function toolButton(command, iconName, label) {
    return `<button type="button" class="lhe-icon-button" data-cmd="${command}" title="${label}" aria-label="${label}">${ns.Icons.svg(iconName)}</button>`;
  }

  function actionButton(action, iconName, label) {
    return `<button type="button" class="lhe-icon-button" data-action="${action}" title="${label}" aria-label="${label}">${ns.Icons.svg(iconName)}</button>`;
  }

  function colorButton(command, label, value) {
    return `<button type="button" class="lhe-icon-button lhe-color-button" data-color-menu="${command}" data-color="${value}" title="${label}" aria-label="${label}">${ns.Icons.svg(command === "foreColor" ? "palette" : "brush")}<span style="background:${value}"></span></button>`;
  }

  function toolbarSelect(name, label, options, selectClass, defaultValue) {
    const body = options
      .map(([text, value]) => `<option value="${value}"${value === defaultValue ? " selected" : ""}>${text}</option>`)
      .join("");
    const placeholder = defaultValue == null ? `<option value="">${label}</option>` : "";
    return `<label class="lhe-field ${selectClass ? `lhe-${selectClass}` : ""}" title="${label}"><select data-style="${name}" aria-label="${label}">${placeholder}${body}</select></label>`;
  }

  function fontSizeSelect() {
    return `<label class="lhe-field lhe-font-size" title="${t("fontSize")}">${ns.Icons.svg("text")}<input type="text" inputmode="numeric" pattern="[0-9]*" data-style="fontSize" value="16" aria-label="${t("fontSize")}"><button type="button" class="lhe-font-menu-button" data-action="fontSizeMenu" title="${t("fontSize")}" aria-label="${t("fontSize")}">${ns.Icons.svg("chevronDown")}</button></label>`;
  }

  function fontSizeValues() {
    return Array.from({ length: 125 }, (_, index) => index + 4);
  }

  function openFontSizeMenu(anchor) {
    closeFontSizeMenu();
    const menu = document.createElement("div");
    menu.className = "lhe-popover lhe-font-size-popover";
    menu.setAttribute("data-lhe-ui", "true");
    menu.setAttribute("contenteditable", "false");
    menu.innerHTML = `
      <div class="lhe-popover-title">${t("fontSize")}</div>
      <div class="lhe-font-size-grid">${fontSizeValues().map((value) => `<button type="button" data-font-size="${value}">${value}</button>`).join("")}</div>
    `;
    document.body.appendChild(menu);
    positionPopover(menu, anchor.getBoundingClientRect());
    state.fontSizeMenu = menu;
    menu.addEventListener("click", (event) => {
      const option = event.target.closest("[data-font-size]");
      if (!option) return;
      const size = Number.parseInt(option.getAttribute("data-font-size"), 10);
      setFontSizeControlValue(size);
      applyFontSize(size);
      closeFontSizeMenu();
    });
  }

  function closeFontSizeMenu() {
    if (state.fontSizeMenu) state.fontSizeMenu.remove();
    state.fontSizeMenu = null;
  }

  function setFontSizeControlValue(size) {
    const input = state.toolbar?.querySelector("[data-style='fontSize']");
    if (!input) return;
    input.dataset.mixed = "false";
    input.setAttribute("value", String(size));
    input.value = String(size);
  }

  function setFontSizeControlMixed() {
    const input = state.toolbar?.querySelector("[data-style='fontSize']");
    if (!input || document.activeElement === input) return;
    input.dataset.mixed = "true";
    input.setAttribute("value", t("mixedFontSize"));
    input.value = t("mixedFontSize");
  }

  function openColorMenu(anchor, command) {
    closeFontSizeMenu();
    closeColorMenu();
    const menu = document.createElement("div");
    menu.className = "lhe-popover lhe-color-popover";
    menu.setAttribute("data-lhe-ui", "true");
    menu.setAttribute("contenteditable", "false");
    menu.innerHTML = `
      <div class="lhe-popover-title">${command === "foreColor" ? t("textColor") : t("highlight")}</div>
      <div class="lhe-swatch-grid">${colorPresets.flat().map((color) => `<button type="button" data-swatch="${color}" title="${color}" style="background:${color}"></button>`).join("")}</div>
      <label class="lhe-rgb-picker">${ns.Icons.svg("palette")}<input type="color" value="${command === "foreColor" ? "#111111" : "#fef08a"}" data-rgb></label>
    `;
    document.body.appendChild(menu);
    positionPopover(menu, anchor.getBoundingClientRect());
    state.colorMenu = menu;
    const rgb = menu.querySelector("[data-rgb]");
    let closeTimer = null;
    const scheduleClose = () => {
      clearTimeout(closeTimer);
      closeTimer = setTimeout(() => {
        if (state.colorMenu === menu && document.activeElement !== rgb && !menu.matches(":hover")) closeColorMenu();
      }, 180);
    };
    menu.addEventListener("mouseenter", () => clearTimeout(closeTimer));
    menu.addEventListener("mouseleave", scheduleClose);
    menu.addEventListener("click", (event) => {
      const swatch = event.target.closest("[data-swatch]");
      if (!swatch) return;
      applyColor(command, swatch.getAttribute("data-swatch"), anchor);
      closeColorMenu();
    });
    rgb.addEventListener("input", (event) => applyColor(command, event.target.value, anchor));
    rgb.addEventListener("change", (event) => {
      applyColor(command, event.target.value, anchor);
      closeColorMenu();
    });
  }

  function applyColor(command, color, anchor) {
    runCommand(command, color);
    anchor.dataset.color = color;
    const dot = anchor.querySelector("span");
    if (dot) dot.style.background = color;
  }

  function closeColorMenu() {
    if (state.colorMenu) state.colorMenu.remove();
    state.colorMenu = null;
  }

  function copyFormat() {
    const source = state.selectedElement || currentBlock();
    if (!source) {
      showToast(t("selectFormatSource"));
      return;
    }
    const computed = getComputedStyle(source);
    state.formatBrush = {
      styles: {
        fontFamily: computed.fontFamily,
        fontSize: computed.fontSize,
        fontWeight: computed.fontWeight,
        fontStyle: computed.fontStyle,
        textDecorationLine: computed.textDecorationLine,
        lineHeight: computed.lineHeight,
        letterSpacing: computed.letterSpacing,
        color: computed.color,
        backgroundColor: computed.backgroundColor,
        textAlign: computed.textAlign,
        verticalAlign: computed.verticalAlign,
        display: computed.display,
        justifyContent: computed.justifyContent
      }
    };
    if (state.toolbar) {
      state.toolbar.querySelector("[data-action='formatBrush']")?.classList.add("is-active");
    }
    showToast(t("formatCopied"));
  }

  function openFormatMenu(target, event) {
    if (!state.formatBrush) return;
    closeFontSizeMenu();
    closeFormatMenu();
    const menu = document.createElement("div");
    menu.className = "lhe-popover lhe-format-popover";
    menu.setAttribute("data-lhe-ui", "true");
    menu.setAttribute("contenteditable", "false");
    menu.innerHTML = `
      <div class="lhe-popover-title">${t("pasteFormat")}</div>
      <button type="button" data-format-mode="all">${t("pasteAllFormats")}</button>
      <button type="button" data-format-mode="text">${t("pasteTextStyle")}</button>
      <button type="button" data-format-mode="colors">${t("pasteColors")}</button>
      <button type="button" data-format-mode="textColor">${t("pasteTextColor")}</button>
      <button type="button" data-format-mode="highlight">${t("pasteHighlight")}</button>
      <button type="button" data-format-mode="alignment">${t("pasteAlignment")}</button>
    `;
    document.body.appendChild(menu);
    positionPopover(menu, { left: event.clientX, top: event.clientY, bottom: event.clientY });
    state.formatMenu = menu;
    menu.addEventListener("click", (clickEvent) => {
      const option = clickEvent.target.closest("[data-format-mode]");
      if (!option) return;
      pasteFormat(target, option.getAttribute("data-format-mode"));
      closeFormatMenu();
      state.formatBrush = null;
      state.toolbar?.querySelector("[data-action='formatBrush']")?.classList.remove("is-active");
    });
  }

  function pasteFormat(target, mode) {
    if (!state.formatBrush || !target) return;
    const styles = state.formatBrush.styles;
    const groups = {
      text: ["fontFamily", "fontSize", "fontWeight", "fontStyle", "textDecorationLine", "lineHeight", "letterSpacing"],
      colors: ["color", "backgroundColor"],
      textColor: ["color"],
      highlight: ["backgroundColor"],
      alignment: ["textAlign", "verticalAlign", "display", "justifyContent"]
    };
    const props = mode === "all" ? [...groups.text, ...groups.colors, ...groups.alignment] : groups[mode] || [];
    props.forEach((prop) => {
      const value = styles[prop];
      if (value && value !== "normal" && value !== "rgba(0, 0, 0, 0)") {
        target.style[prop] = value;
      }
    });
    noteChange();
  }

  function closeFormatMenu() {
    if (state.formatMenu) state.formatMenu.remove();
    state.formatMenu = null;
  }

  function positionPopover(popover, rect) {
    const left = Math.min(window.innerWidth - 260, Math.max(12, rect.left));
    const top = Math.min(window.innerHeight - 320, Math.max(58, rect.bottom + 8));
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  }

  function handleToolbarClick(event) {
    const fontInput = event.target.closest("[data-style='fontSize']");
    if (fontInput) {
      saveSelection();
      if (fontInput.dataset.mixed === "true") fontInput.select();
      openFontSizeMenu(fontInput);
      return;
    }
    const button = event.target.closest("button");
    if (!button) return;
    const cmd = button.getAttribute("data-cmd");
    const action = button.getAttribute("data-action");
    const colorCommand = button.getAttribute("data-color-menu");
    if (cmd === "indent" || cmd === "outdent") {
      applyTextIndent(cmd === "indent" ? 1 : -1);
    } else if (cmd) {
      runCommand(cmd);
    }
    if (colorCommand) openColorMenu(button, colorCommand);
    if (action === "fontSizeMenu") {
      saveSelection();
      openFontSizeMenu(button);
    }
    if (action === "link") createLink();
    if (action === "image") state.imageInput.click();
    if (action === "imageWidth") setImageWidth();
    if (action === "formatBrush") copyFormat();
    if (action === "saveHtml") saveAsHtml();
    if (action === "saveZip") saveAsZip();
    if (action === "history") openHistoryDrawer();
  }

  function handleToolbarChange(event) {
    const target = event.target;
    if (target.matches("[data-style='fontSize']") && target.value) {
      const parsed = Number.parseInt(target.value, 10);
      if (!Number.isFinite(parsed)) {
        updateFontSizeControlFromSelection();
        return;
      }
      const size = Math.max(4, Math.min(128, parsed));
      setFontSizeControlValue(size);
      applyFontSize(size);
    }
    if (target.matches("[data-style='lineHeight']") && target.value) {
      applyBlockStyle("lineHeight", target.value);
    }
    if (target.matches("[data-style='verticalAlign']") && target.value) {
      applyVerticalAlign(target.value);
    }
    if (target.matches("[data-style='align']") && target.value) {
      applyHorizontalAlign(target.value);
    }
  }

  function handleToolbarKeydown(event) {
    const target = event.target;
    if (!target.matches("[data-style='fontSize']")) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      openFontSizeMenu(target);
      return;
    }
    if (event.key !== "Enter") return;
    event.preventDefault();
    handleToolbarChange({ target });
  }

  function saveSelection() {
    if (!state.editing) return;
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const node = selection.anchorNode;
    const element = node ? closestElement(node) : null;
    if (element && element.closest("[data-lhe-ui]")) return;
    state.savedRange = selection.getRangeAt(0).cloneRange();
    updateFontSizeControlFromSelection();
  }

  function restoreSelection() {
    if (!state.savedRange) return;
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(state.savedRange);
  }

  function runCommand(command, value) {
    restoreSelection();
    document.execCommand(command, false, value || null);
    noteChange();
  }

  function applyFontSize(size) {
    restoreSelection();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
      const target = currentTextBlock() || currentBlock();
      if (target) target.style.fontSize = `${size}px`;
      noteChange();
      return;
    }
    const existingFonts = new Set(document.querySelectorAll("font[size='7']"));
    document.execCommand("styleWithCSS", false, false);
    document.execCommand("fontSize", false, "7");
    document.execCommand("styleWithCSS", false, true);
    document.querySelectorAll("font[size='7']").forEach((font) => {
      if (existingFonts.has(font)) return;
      const span = document.createElement("span");
      span.style.fontSize = `${size}px`;
      span.innerHTML = font.innerHTML;
      font.replaceWith(span);
    });
    noteChange();
  }

  function applyBlockStyle(property, value) {
    restoreSelection();
    const target = currentTextBlock() || currentBlock();
    if (!target) return;
    target.style[property] = value;
    noteChange();
  }

  function applyVerticalAlign(value) {
    restoreSelection();
    const selected = state.selectedElement && isEditableTarget(state.selectedElement) ? state.selectedElement : null;
    const block = currentTextBlock() || currentBlock();
    const target = selected && (selected.tagName === "IMG" || ["TD", "TH"].includes(selected.tagName)) ? selected : block;
    if (!target) return;
    const normalized = value === "middle" ? "center" : value;
    if (["TD", "TH"].includes(target.tagName)) {
      target.style.verticalAlign = value;
    } else if (target.tagName === "IMG" || getComputedStyle(target).display === "inline") {
      target.style.verticalAlign = value;
    } else {
      if (!target.style.minHeight && target.getBoundingClientRect().height < 72) {
        target.style.minHeight = "96px";
      }
      target.style.display = "flex";
      target.style.flexDirection = "column";
      target.style.justifyContent = normalized === "top" ? "flex-start" : normalized === "bottom" ? "flex-end" : "center";
    }
    noteChange();
  }

  function applyHorizontalAlign(value) {
    restoreSelection();
    if (state.selectedElement && state.selectedElement.tagName === "IMG") {
      const img = state.selectedElement;
      img.style.display = "block";
      if (value === "left") {
        img.style.marginLeft = "0";
        img.style.marginRight = "auto";
      } else if (value === "right") {
        img.style.marginLeft = "auto";
        img.style.marginRight = "0";
      } else {
        img.style.marginLeft = "auto";
        img.style.marginRight = "auto";
      }
      noteChange();
      return;
    }
    const target = currentTextBlock();
    if (!target) return;
    target.style.textAlign = value === "full" ? "justify" : value;
    noteChange();
  }

  function applyTextIndent(direction) {
    restoreSelection();
    const target = currentTextBlock();
    if (!target) return;
    const computed = getComputedStyle(target);
    const current = parseFloat(target.style.paddingInlineStart || target.style.paddingLeft || computed.paddingLeft) || 0;
    const next = Math.max(0, current + direction * 24);
    target.style.paddingInlineStart = next ? `${next}px` : "";
    noteChange();
  }

  function createLink() {
    restoreSelection();
    const url = window.prompt(t("linkPrompt"));
    if (!url) return;
    runCommand("createLink", url);
  }

  function setImageWidth() {
    const img = state.selectedElement && state.selectedElement.tagName === "IMG" ? state.selectedElement : null;
    if (!img) {
      showToast(t("selectImageFirst"));
      return;
    }
    const width = window.prompt(t("widthPrompt"), img.style.width || img.getAttribute("width") || "100%");
    if (!width) return;
    img.style.width = width;
    img.style.height = "auto";
    noteChange();
  }

  function handleImagePicked(event) {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    insertOrReplaceImage(file);
  }

  async function insertOrReplaceImage(file) {
    const dataURL = await ns.Utils.readFileAsDataURL(file);
    const img = state.selectedElement && state.selectedElement.tagName === "IMG" ? state.selectedElement : document.createElement("img");
    img.src = dataURL;
    img.alt = file.name.replace(/\.[^.]+$/, "");
    img.style.maxWidth = "100%";
    img.style.height = "auto";
    img.setAttribute("data-lhe-new-image", "true");
    img.setAttribute("data-lhe-file-name", file.name || `${ns.Utils.uniqueId("image")}.${ns.Utils.extensionFromMime(file.type)}`);
    if (!img.parentNode) insertNodeAtCursor(img);
    selectElement(img);
    noteChange();
  }

  function insertNodeAtCursor(node) {
    restoreSelection();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      document.body.appendChild(node);
      return;
    }
    const range = selection.getRangeAt(0);
    range.deleteContents();
    range.insertNode(node);
    range.setStartAfter(node);
    range.setEndAfter(node);
    selection.removeAllRanges();
    selection.addRange(range);
    saveSelection();
  }

  function handlePaste(event) {
    if (!state.editing || event.target.closest("[data-lhe-ui]")) return;
    const items = event.clipboardData && event.clipboardData.items ? [...event.clipboardData.items] : [];
    const item = items.find((entry) => entry.type && entry.type.startsWith("image/"));
    if (!item) return;
    const file = item.getAsFile();
    if (!file) return;
    event.preventDefault();
    insertOrReplaceImage(file);
  }

  function handleShortcuts(event) {
    if (!state.editing || event.target.closest("[data-lhe-ui]")) return;
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveAsHtml();
    }
  }

  function handleDocumentClick(event) {
    if (!state.editing || event.target.closest("[data-lhe-ui]")) return;
    closeFontSizeMenu();
    const target = event.target.closest("img, p, h1, h2, h3, h4, h5, h6, li, blockquote, td, th, div, span, a, button");
    if (!target || !isEditableTarget(target)) return;
    selectElement(target);
    if (state.formatBrush) {
      event.preventDefault();
      event.stopPropagation();
      openFormatMenu(target, event);
    }
  }

  function handleHover(event) {
    if (!state.editing || event.target.closest("[data-lhe-ui]")) return;
    const target = event.target.closest("img, p, h1, h2, h3, h4, h5, h6, li, blockquote, td, th, div, span, a, button");
    if (target && isEditableTarget(target)) target.classList.add("lhe-hover");
  }

  function clearHover() {
    document.querySelectorAll(".lhe-hover").forEach((node) => node.classList.remove("lhe-hover"));
  }

  function selectElement(element) {
    clearSelectionMarker();
    state.selectedElement = element;
    element.classList.add("lhe-selected");
    updateFontSizeControlFromSelection();
  }

  function clearSelectionMarker() {
    document.querySelectorAll(".lhe-selected").forEach((node) => node.classList.remove("lhe-selected"));
    state.selectedElement = null;
  }

  function isEditableTarget(element) {
    if (!element || element.closest("[data-lhe-ui]")) return false;
    return !["SCRIPT", "STYLE", "SVG", "CANVAS", "VIDEO", "AUDIO", "IFRAME", "INPUT", "TEXTAREA", "SELECT"].includes(element.tagName);
  }

  function closestElement(node) {
    return node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
  }

  function currentBlock() {
    if (state.selectedElement && isEditableTarget(state.selectedElement)) return state.selectedElement;
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return null;
    const element = closestElement(selection.anchorNode);
    return element ? element.closest("p,h1,h2,h3,h4,h5,h6,li,blockquote,td,th,div,span,a,button,img") : null;
  }

  function currentTextBlock() {
    const source = state.selectedElement && isEditableTarget(state.selectedElement) ? state.selectedElement : currentBlock();
    if (!source || source.tagName === "IMG") return null;
    return source.closest("p,h1,h2,h3,h4,h5,h6,li,blockquote,td,th,div") || source;
  }

  function updateFontSizeControlFromSelection() {
    const input = state.toolbar?.querySelector("[data-style='fontSize']");
    if (!input || document.activeElement === input) return;
    const result = currentFontSizeState();
    if (!result) return;
    if (result === "mixed") {
      setFontSizeControlMixed();
    } else {
      setFontSizeControlValue(result);
    }
  }

  function currentFontSizeState() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
      const target = currentTextBlock();
      return target ? fontSizeValueForElement(target) : null;
    }
    const range = selection.getRangeAt(0);
    const values = fontSizesInRange(range);
    if (values.size === 0) {
      const target = currentTextBlock();
      return target ? fontSizeValueForElement(target) : null;
    }
    if (values.size === 1) return [...values][0];
    return "mixed";
  }

  function fontSizesInRange(range) {
    const values = new Set();
    const root = range.commonAncestorContainer.nodeType === Node.TEXT_NODE
      ? range.commonAncestorContainer.parentElement
      : range.commonAncestorContainer;
    if (!root) return values;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.textContent || !node.textContent.trim()) return NodeFilter.FILTER_REJECT;
        const element = closestElement(node);
        if (!element || element.closest("[data-lhe-ui]")) return NodeFilter.FILTER_REJECT;
        return range.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let node = walker.nextNode();
    while (node) {
      const value = fontSizeValueForElement(closestElement(node));
      if (value) values.add(value);
      node = walker.nextNode();
    }
    return values;
  }

  function fontSizeValueForElement(element) {
    if (!element) return null;
    const value = Number.parseFloat(getComputedStyle(element).fontSize);
    return Number.isFinite(value) ? String(Math.round(value)) : null;
  }

  function noteChange() {
    if (!state.editing) return;
    const today = ns.Utils.dateKey(Date.now());
    if (state.lastSnapshotDate && state.lastSnapshotDate !== today) {
      createSnapshot("day-change", "auto");
      state.lastSnapshotDate = today;
    }
    setStatus(t("saving"));
    autosave();
  }

  async function saveDraft() {
    try {
      const exportResult = ns.Exporter.prepareExport(document, "html");
      const now = Date.now();
      const draft = {
        fingerprint: state.fingerprint,
        url: window.location.href,
        title: document.title || t("appName"),
        html: exportResult.html,
        updatedAt: now,
        dateKey: ns.Utils.dateKey(now),
        size: exportResult.html.length
      };
      await ns.Store.saveDraft(draft);
      state.currentDraft = draft;
      setStatus(`${t("autosaved")} ${ns.Utils.formatClock(now)}`);
    } catch (error) {
      console.error(error);
      setStatus(t("autosaveFailed"));
    }
  }

  async function createSnapshot(reason, saveType) {
    try {
      const exportResult = ns.Exporter.prepareExport(document, "html");
      const now = Date.now();
      const snapshot = {
        id: ns.Utils.uniqueId("snapshot"),
        fingerprint: state.fingerprint,
        url: window.location.href,
        title: document.title || t("appName"),
        html: exportResult.html,
        reason,
        saveType,
        createdAt: now,
        size: exportResult.html.length
      };
      await ns.Store.addSnapshot(snapshot);
      return snapshot;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  async function saveAsHtml() {
    await createSnapshot("save", "html");
    const result = ns.Exporter.prepareExport(document, "html");
    const blob = new Blob([result.html], { type: "text/html;charset=utf-8" });
    const url = await ns.Utils.blobToDataURL(blob);
    const filename = `${baseExportName()}.html`;
    download(url, filename);
  }

  async function saveAsZip() {
    await createSnapshot("save", "zip");
    try {
      const result = ns.Exporter.prepareExport(document, "zip");
      const entries = [{ name: "index.html", data: result.html }, ...result.assets];
      const blob = ns.Zip.createZipBlob(entries);
      const url = await ns.Utils.blobToDataURL(blob);
      download(url, `${baseExportName()}.zip`);
    } catch (error) {
      console.error(error);
      showFullscreenError(t("zipFailed"));
    }
  }

  function download(url, filename) {
    chrome.runtime.sendMessage({ type: "lhe-download", url, filename }, (response) => {
      if (!response || !response.ok) {
        showFullscreenError((response && response.error) || t("saveFailed"));
      }
    });
  }

  function baseExportName() {
    const title = document.title || decodeURIComponent(window.location.pathname.split("/").pop() || "index.html");
    return ns.Utils.safeFileName(title.replace(/\.html?$/i, ""), "index");
  }

  async function openHistoryDrawer() {
    if (state.historyDrawer && document.contains(state.historyDrawer)) {
      state.historyDrawer.remove();
      state.historyDrawer = null;
      return;
    }
    const drawer = document.createElement("aside");
    drawer.id = "lhe-history-drawer";
    drawer.setAttribute("data-lhe-ui", "true");
    drawer.setAttribute("contenteditable", "false");
    drawer.innerHTML = `<header><strong>${t("historyVersions")}</strong><button type="button" class="lhe-icon-button" data-close title="${t("exitEditMode")}" aria-label="${t("exitEditMode")}">${ns.Icons.svg("close")}</button></header><div class="lhe-history-list">${t("loading")}</div>`;
    document.body.appendChild(drawer);
    state.historyDrawer = drawer;
    drawer.querySelector("[data-close]").addEventListener("click", () => drawer.remove());
    await renderHistoryList(drawer.querySelector(".lhe-history-list"));
  }

  async function renderHistoryList(container) {
    const rows = await ns.Store.listSnapshots(state.fingerprint);
    if (!rows.length) {
      container.textContent = t("noHistory");
      return;
    }
    container.innerHTML = "";
    rows.forEach((row) => {
      const item = document.createElement("div");
      item.className = "lhe-history-item";
      item.innerHTML = `
        <div><strong>${escapeText(row.title)}</strong></div>
        <small>${new Date(row.createdAt).toLocaleString("zh-CN", { hour12: false })} · ${escapeText(row.saveType || row.reason)} · ${ns.Utils.sizeLabel(row.size || row.html.length)}</small>
        <div class="lhe-history-actions">
          <button type="button" class="lhe-icon-button" data-preview title="${t("preview")}" aria-label="${t("preview")}">${ns.Icons.svg("eye")}</button>
          <button type="button" class="lhe-icon-button" data-export title="${t("export")}" aria-label="${t("export")}">${ns.Icons.svg("save")}</button>
          <button type="button" class="lhe-icon-button" data-restore title="${t("restore")}" aria-label="${t("restore")}">${ns.Icons.svg("history")}</button>
        </div>
      `;
      item.querySelector("[data-preview]").addEventListener("click", () => previewHtml(row.html));
      item.querySelector("[data-export]").addEventListener("click", () => exportSnapshot(row));
      item.querySelector("[data-restore]").addEventListener("click", () => restoreSnapshot(row));
      container.appendChild(item);
    });
  }

  function previewHtml(html) {
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank", "noopener");
  }

  async function exportSnapshot(row) {
    const blob = new Blob([row.html], { type: "text/html;charset=utf-8" });
    const url = await ns.Utils.blobToDataURL(blob);
    download(url, `${ns.Utils.safeFileName(row.title, "history")}-${row.createdAt}.html`);
  }

  async function restoreSnapshot(snapshot) {
    if (!snapshot || !snapshot.html) return { ok: false, error: t("invalidHistory") };
    const ok = window.confirm(t("restoreHistoryConfirm"));
    if (!ok) return { ok: false, cancelled: true };
    await createSnapshot("before-restore", "restore");
    loadHtmlIntoPage(snapshot.html);
    injectFloatingButton();
    if (state.editing) {
      state.toolbar = null;
      injectToolbar();
      document.body.classList.add("lhe-editing");
      document.body.setAttribute("contenteditable", "true");
      document.body.setAttribute("spellcheck", "false");
    }
    noteChange();
    showToast(t("restoredHistory"));
    return { ok: true };
  }

  function loadHtmlIntoPage(html) {
    const parsed = new DOMParser().parseFromString(html, "text/html");
    copyAttributes(parsed.documentElement, document.documentElement);
    copyAttributes(parsed.body, document.body);
    document.head.innerHTML = parsed.head.innerHTML;
    document.body.innerHTML = parsed.body.innerHTML;
  }

  function copyAttributes(from, to) {
    [...to.attributes].forEach((attr) => to.removeAttribute(attr.name));
    [...from.attributes].forEach((attr) => to.setAttribute(attr.name, attr.value));
  }

  function showDraftBanner(draft) {
    const banner = document.createElement("div");
    banner.id = "lhe-draft-banner";
    banner.setAttribute("data-lhe-ui", "true");
    banner.setAttribute("contenteditable", "false");
    banner.innerHTML = `
      <span>${t("detectedDraft")}：${new Date(draft.updatedAt).toLocaleString("zh-CN", { hour12: false })}</span>
      <button type="button" class="lhe-icon-button" data-restore title="${t("restoreDraft")}" aria-label="${t("restoreDraft")}">${ns.Icons.svg("history")}</button>
      <button type="button" class="lhe-icon-button" data-close title="${t("ignore")}" aria-label="${t("ignore")}">${ns.Icons.svg("close")}</button>
    `;
    banner.querySelector("[data-restore]").addEventListener("click", () => {
      if (window.confirm(t("restoreDraftConfirm"))) {
        loadHtmlIntoPage(draft.html);
        injectFloatingButton();
        showToast(t("restoredDraft"));
      }
    });
    banner.querySelector("[data-close]").addEventListener("click", () => banner.remove());
    document.body.appendChild(banner);
  }

  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "lhe-toast";
    toast.setAttribute("data-lhe-ui", "true");
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2200);
  }

  function showFullscreenError(message) {
    const modal = document.createElement("div");
    modal.className = "lhe-error-modal";
    modal.setAttribute("data-lhe-ui", "true");
    modal.setAttribute("contenteditable", "false");
    modal.innerHTML = `<div><h2>${t("errorTitle")}</h2><p>${escapeText(message)}</p><button type="button" class="lhe-icon-button" title="${t("ignore")}" aria-label="${t("ignore")}">${ns.Icons.svg("close")}</button></div>`;
    modal.querySelector("button").addEventListener("click", () => modal.remove());
    document.body.appendChild(modal);
  }

  function setStatus(text) {
    if (state.statusNode) state.statusNode.textContent = text;
  }

  function escapeText(value) {
    return String(value || "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[char]);
  }
})();
