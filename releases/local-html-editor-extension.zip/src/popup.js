(function initPopup() {
  const ns = window.LocalHtmlEditor;
  const statusNode = document.querySelector("#page-status");
  const listNode = document.querySelector("#history-list");
  const refreshButton = document.querySelector("#refresh");
  const t = ns.I18n.t;
  let activeTab = null;
  let pageInfo = null;

  localizeStaticText();
  refreshButton.innerHTML = ns.Icons.svg("refresh");
  refreshButton.title = t("refresh");
  refreshButton.setAttribute("aria-label", t("refresh"));
  refreshButton.addEventListener("click", load);
  load();

  async function load() {
    statusNode.textContent = t("popupStatusChecking");
    activeTab = await getActiveTab();
    pageInfo = await getPageInfo(activeTab);
    renderStatus();
    await renderHistory();
  }

  function getActiveTab() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs && tabs[0] ? tabs[0] : null));
    });
  }

  function getPageInfo(tab) {
    return new Promise((resolve) => {
      if (!tab || !tab.id) {
        resolve(null);
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: "lhe-get-page-info" }, (response) => {
        if (chrome.runtime.lastError || !response || !response.ok) {
          resolve(null);
          return;
        }
        resolve(response);
      });
    });
  }

  function renderStatus() {
    if (!activeTab) {
      statusNode.textContent = t("popupNoTab");
      return;
    }
    if (!pageInfo) {
      statusNode.textContent = t("popupUnsupported");
      return;
    }
    statusNode.textContent = `${t("popupCurrentFile")}：${pageInfo.title || t("appName")}`;
  }

  async function renderHistory() {
    const rows = await ns.Store.listSnapshots(pageInfo ? pageInfo.fingerprint : undefined);
    if (!rows.length) {
      listNode.innerHTML = `<p class="empty">${t("noHistory")}</p>`;
      return;
    }
    listNode.innerHTML = "";
    rows.forEach((row) => listNode.appendChild(renderHistoryItem(row)));
  }

  function renderHistoryItem(row) {
    const item = document.createElement("div");
    item.className = "history-item";
    item.innerHTML = `
      <strong>${escapeText(row.title || t("appName"))}</strong>
      <small>${new Date(row.createdAt).toLocaleString("zh-CN", { hour12: false })} · ${escapeText(row.saveType || row.reason || "snapshot")} · ${ns.Utils.sizeLabel(row.size || row.html.length)}</small>
      <div class="history-actions">
        <button type="button" data-preview title="${t("preview")}" aria-label="${t("preview")}">${ns.Icons.svg("eye")}</button>
        <button type="button" data-export title="${t("export")}" aria-label="${t("export")}">${ns.Icons.svg("save")}</button>
        <button type="button" data-restore title="${t("restore")}" aria-label="${t("restore")}">${ns.Icons.svg("history")}</button>
      </div>
    `;
    item.querySelector("[data-preview]").addEventListener("click", () => preview(row));
    item.querySelector("[data-export]").addEventListener("click", () => exportSnapshot(row));
    item.querySelector("[data-restore]").addEventListener("click", () => restore(row));
    return item;
  }

  function preview(row) {
    const blob = new Blob([row.html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    chrome.tabs.create({ url });
  }

  async function exportSnapshot(row) {
    const blob = new Blob([row.html], { type: "text/html;charset=utf-8" });
    const url = await ns.Utils.blobToDataURL(blob);
    const filename = `${ns.Utils.safeFileName(row.title || "history", "history")}-${row.createdAt}.html`;
    chrome.runtime.sendMessage({ type: "lhe-download", url, filename }, (response) => {
      if (!response || !response.ok) alert((response && response.error) || t("exportFailed"));
    });
  }

  function restore(row) {
    if (!activeTab || !activeTab.id || !pageInfo) {
      alert(t("restoreNeedsPage"));
      return;
    }
    chrome.tabs.sendMessage(activeTab.id, { type: "lhe-restore-snapshot", snapshot: row }, (response) => {
      if (chrome.runtime.lastError) {
        alert(t("restoreFailed"));
        return;
      }
      if (response && response.cancelled) return;
      if (!response || !response.ok) alert((response && response.error) || t("restoreFailed"));
      window.close();
    });
  }

  function escapeText(value) {
    return String(value || "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[char]);
  }

  function localizeStaticText() {
    document.title = t("appName");
    document.querySelectorAll("[data-i18n]").forEach((node) => {
      node.textContent = t(node.getAttribute("data-i18n"));
    });
  }
})();
